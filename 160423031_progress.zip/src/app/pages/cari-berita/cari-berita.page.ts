import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cari-berita',
  templateUrl: './cari-berita.page.html',
  styleUrls: ['./cari-berita.page.scss'],
})
export class CariBeritaPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
