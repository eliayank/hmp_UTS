import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-baca-berita',
  templateUrl: './baca-berita.page.html',
  styleUrls: ['./baca-berita.page.scss'],
})
export class BacaBeritaPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
