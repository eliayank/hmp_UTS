import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-favorit',
  templateUrl: './favorit.page.html',
  styleUrls: ['./favorit.page.scss'],
})
export class FavoritPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
